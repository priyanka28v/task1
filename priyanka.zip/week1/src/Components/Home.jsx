import Signup from "./Signup";

const Home=()=>{
    return(
        <>
        <Signup/>
        </>
    )
}

export default Home