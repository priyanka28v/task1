import { Formik, useFormik } from "formik"
import PhoneInput from 'react-phone-input-2'
import 'react-phone-input-2/lib/style.css'
import * as yup from "yup"

const Signup=()=>{

    const formik=useFormik({
        initialValues:{
            username:"",
            email:"",
            password:"",
            contact:"",
            twitter:"",
            linkedin:"",
            facebook:"",
            companyName:"",
            jobTitle:"",
            website:"",
        },
       validationSchema: yup.object({

            username:yup
                .string()
                .required("Username is required"),

              email: yup
                .string()
                .email("Invalid email format")
                .required("Email is required"),

              twitter:yup
              .string(),

              facebook:yup 
              .string()
              .url("Invalid Url format"),

              linkedin:yup 
              .string()
              .url("Invalid Url format"),

               companyName:yup
                .string()
                .required("CompanyName is required"),

                jobTitle:yup
                .string()
                .required("jobtile is required"),

                  website:yup 
                  .string()
                  .url("Invalid Url format"),            

        }),
        onSubmit:(values)=>{
          console.log(values)
            const userData=sessionStorage.setItem("info",values)
            console.log(userData)
        }

    })
    console.log(formik)
    return(
        <>
         <h1 className="md:text-3xl md:font-bold md:place-self-center">Signup Form</h1>
         <div className="flex flex-row  mt-8 ml-[200px] gap-y-8">
         <form onSubmit={formik.onSubmit}>

                {/* Personal Information */}

                {/* username */}
                <div className="flex flex-col md:place-self-center ">
                    <label htmlFor="username" placeholder="username"
                    className="md:text-xl md:m-4"
                    >Enter username:
                    </label>
                    

                    <input type="text" id="username" 
                     placeholder="username"
                     name="username"
                     className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}

                    />

                        {formik.touched.username  && formik.errors.username && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.username}
                        </div>
                    )}

                {/* email */}

                    <label htmlFor="email" 
                     className="md:text-xl md:m-4">
                        Enter email:
                        </label>

                    <input type="email" id="email" 
                     placeholder="Email"
                     name="email"
                      className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                
                    />
                    {formik.touched.email && formik.errors.email && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.email}
                        </div>
                    )}

                    {/* contact details  */}

                    <label htmlFor="Contact details:" 
                     className="md:text-xl md:m-4">
                        Enter Contact:
                        </label>

                   <PhoneInput
                    country={'us'}
                    name="contact"
                    className="md:rounded-lg md:p-3  md:border-black md:outline-2 md:outline-black"                   
                    />                  
                    
                 {formik.touched.contact  && formik.errors.contact && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.contact}
                        </div>
                    )}
                 {/* Social Media */}

                 {/* twitter account     */}
                    
                    <label htmlFor="Twitter" 
                     className="md:text-xl md:m-4">
                    Twitter Account:
                    </label>

                  <input type="text" id="twitter" 
                     placeholder="twitter"
                      className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                      name="twitter"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                      />

                      {formik.touched.twitter && formik.errors.twitter && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.twitter}
                        </div>
                    )}


                    {/* linkedin account */}

                     <label htmlFor="Linkedin" 
                     className="md:text-xl md:m-4">
                    Linkedin Account:
                    </label>

                  <input type="link" id="Linkedin" 
                     placeholder="Linkedin"
                     name="linkedin"
                      className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    />

                      {formik.touched.linkedin && formik.errors.linkedin && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.linkedin}
                        </div>
                    )}

                    
                    

                    {/* facebook account  */}

                     <label htmlFor="facebook" 
                     className="md:text-xl md:m-4">
                    Facebook Account:
                    </label>

                  <input type="link" id="facebook" 
                     placeholder="facebook"
                      className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                      name="facebook"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                 </div>

                 {formik.touched.facebook && formik.errors.facebook && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.facebook}
                        </div>
                    )}

                {/* company infomation */}

                <div className="flex flex-col md:place-self-center ">
                            
                 {/* company name  */}

                <label htmlFor="companyName" 
                    className="md:text-xl md:m-4">
                    Company Name:
                    </label>

                  <input type="text" id="companyName" 
                     placeholder="Enter company name"
                      className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                      name="companyName"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    />

                     {formik.touched.companyName && formik.errors.companyName&& (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.companyName}
                        </div>
                    )}

                    {/* job title  */}

                     <label htmlFor="jobTitle" 
                     className="md:text-xl md:m-4">
                    job title
                    </label>

                  <input type="text" id="jobTitle" 
                     placeholder="job title"
                      className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                      name="jobTitle"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    />

                     {formik.touched.jobTitle && formik.errors.jobTitle && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.jobTitle}
                        </div>
                    )}

                    {/* company website  */}
                    
                    <label htmlFor="website" 
                     className="md:text-xl md:m-4">
                    company website:
                    </label>

                  <input type="link" id="website" 
                     placeholder="company website"
                      className="md:rounded-lg md:p-3 md:border-black md:outline-2 md:outline-black"
                      name="website"
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                   />

                     {formik.touched.website && formik.errors.website && (
                      <div className="md:p-3 md:text-red-700 md:font-bold">
                        {formik.errors.website}
                        </div>
                    )}

                <button type="submit"
                className="md:rounded-xl  md:outline-black md:border-black md:border-2 md:outline-black md:mt-[40px] md:pt-[10px] md:pb:5 md:text-2xl md:font-bold md:bg-blue-500 md:w-40 md:text-white md:hover:bg-blue-700 md:cursor-pointer">submit</button>
                         </div>


            </form>
        </div>
        </>
    )
}

export default Signup