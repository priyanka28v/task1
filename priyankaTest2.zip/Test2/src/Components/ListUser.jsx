
import { useEffect,useState } from "react"

export const ListUser=()=>{

    const [data,setData]=useState([])

    useEffect(()=>{
        const listData=JSON.parse(sessionStorage.getItem('users'))
        console.log(listData)
        setData(listData)
    },[])
    console.log(data.userForms)
    return(
    <>

    <table>
        <thead>
            <tr>
                fullname
            </tr>
            <tr>
                email
            </tr>
            <tr>
                contact
            </tr>
            <tr>
                skills
            </tr>
            <tr>
                discription
            </tr>
        </thead>
        {/* {data.&& (
        <tbody>
            {data.userForms.map((user,index)=>(
                <>
                <tr></tr>
                </>
            )) }
        </tbody>
        )} */}
    </table>
    </>
    )
}